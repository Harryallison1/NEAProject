from django.apps import AppConfig


class RevisionmodeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'revisionmode'
